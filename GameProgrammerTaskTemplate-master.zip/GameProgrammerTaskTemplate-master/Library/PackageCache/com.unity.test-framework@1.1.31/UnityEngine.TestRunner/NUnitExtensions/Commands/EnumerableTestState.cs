using System;

namespace UnityEngine.TestTools
{
    [Serializable]
    internal class EnumerableTestState
    {
        public int Repeat;
        public int Retry;
    }
}