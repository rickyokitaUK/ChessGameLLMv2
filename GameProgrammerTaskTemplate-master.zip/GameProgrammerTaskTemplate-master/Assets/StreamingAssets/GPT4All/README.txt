Put the 'ggml-gpt4all-j-v1.3-groovy.bin' model in this folder
